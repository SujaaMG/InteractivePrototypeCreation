import { useNavigate } from "react-router";
import { ListRow } from "../components/ListRow";
import { ArrowLeft, Search } from "lucide-react";

export function NewMessage() {
  const navigate = useNavigate();

  const contacts = [
    {
      name: "Jordan Chen",
      preview: "Software Developer",
      initials: "JC",
      color: "purple" as const,
    },
    {
      name: "Alex Kim",
      preview: "Designer",
      initials: "AK",
      color: "teal" as const,
    },
    {
      name: "Sam Rivera",
      preview: "Product Manager",
      initials: "SR",
      color: "coral" as const,
    },
    {
      name: "Morgan Lee",
      preview: "Engineer",
      initials: "ML",
      color: "blue" as const,
    },
  ];

  return (
    <div className="min-h-screen bg-[var(--app-bg)]">
      {/* Header */}
      <div className="bg-white px-4 py-4 border-b border-gray-200">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={() => navigate("/chats")} className="p-1">
            <ArrowLeft size={24} className="text-[var(--text-primary)]" />
          </button>
          <h1 className="text-xl text-[var(--text-primary)]">New Message</h1>
        </div>
        
        <div className="relative">
          <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-secondary)]" />
          <input
            type="text"
            placeholder="Search contacts..."
            className="w-full pl-12 pr-4 py-3 bg-[var(--app-bg)] rounded-xl border-0 text-[var(--text-primary)] placeholder:text-[var(--text-secondary)]"
          />
        </div>
      </div>

      {/* Contacts */}
      <div className="mt-4">
        {contacts.map((contact, index) => (
          <div key={index} className="mb-1">
            <ListRow {...contact} onClick={() => navigate(`/thread/${contact.name}`)} />
          </div>
        ))}
      </div>
    </div>
  );
}
