import { useNavigate } from "react-router";

export function Login() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[var(--app-bg)] flex flex-col items-center justify-center px-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-[var(--app-accent)] rounded-3xl mx-auto mb-6 flex items-center justify-center">
            <div className="w-12 h-12 bg-white rounded-2xl"></div>
          </div>
          <h1 className="text-3xl mb-2 text-[var(--text-primary)]">Welcome back</h1>
          <p className="text-[var(--text-secondary)]">Sign in to continue</p>
        </div>

        <div className="space-y-4">
          <input
            type="email"
            placeholder="Email"
            className="w-full px-4 py-3 bg-white rounded-xl border-0 text-[var(--text-primary)] placeholder:text-[var(--text-secondary)]"
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full px-4 py-3 bg-white rounded-xl border-0 text-[var(--text-primary)] placeholder:text-[var(--text-secondary)]"
          />
          <button
            onClick={() => navigate("/feed")}
            className="w-full px-4 py-3 bg-[var(--app-accent)] text-white rounded-xl"
          >
            Sign in
          </button>
        </div>

        <p className="text-center text-[var(--text-secondary)] text-sm mt-6">
          Don't have an account?{" "}
          <span className="text-[var(--app-accent)]">Sign up</span>
        </p>
      </div>
    </div>
  );
}
