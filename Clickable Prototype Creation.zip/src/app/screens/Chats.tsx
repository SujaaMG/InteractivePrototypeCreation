import { useNavigate } from "react-router";
import { ListRow } from "../components/ListRow";
import { TabBar } from "../components/TabBar";
import { Edit3 } from "lucide-react";

export function Chats() {
  const navigate = useNavigate();

  const conversations = [
    {
      name: "Jordan Chen",
      preview: "See you tomorrow!",
      initials: "JC",
      color: "purple" as const,
      time: "2m",
      unread: true,
    },
    {
      name: "Alex Kim",
      preview: "Thanks for the help 😊",
      initials: "AK",
      color: "teal" as const,
      time: "1h",
      unread: false,
    },
    {
      name: "Sam Rivera",
      preview: "That sounds great",
      initials: "SR",
      color: "coral" as const,
      time: "5h",
      unread: false,
    },
    {
      name: "Morgan Lee",
      preview: "Let's catch up soon",
      initials: "ML",
      color: "blue" as const,
      time: "1d",
      unread: false,
    },
  ];

  return (
    <div className="min-h-screen bg-[var(--app-bg)] pb-20">
      <div className="bg-white px-4 py-6 border-b border-gray-200 flex items-center justify-between">
        <h1 className="text-2xl text-[var(--text-primary)]">Messages</h1>
        <button
          onClick={() => navigate("/new-message")}
          className="p-2 text-[var(--app-accent)]"
        >
          <Edit3 size={24} />
        </button>
      </div>

      <div className="mt-4">
        {conversations.map((item, index) => (
          <div key={index} className="mb-1">
            <ListRow {...item} onClick={() => navigate(`/thread/${item.name}`)} />
          </div>
        ))}
      </div>

      <TabBar />
    </div>
  );
}
