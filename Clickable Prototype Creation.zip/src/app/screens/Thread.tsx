import { useNavigate, useParams } from "react-router";
import { Avatar } from "../components/Avatar";
import { ChatBubble } from "../components/ChatBubble";
import { ArrowLeft, Send } from "lucide-react";
import { useState } from "react";

export function Thread() {
  const navigate = useNavigate();
  const { name } = useParams();
  const [message, setMessage] = useState("");

  // Map names to avatar data
  const avatarData: Record<string, { initials: string; color: "purple" | "teal" | "coral" | "blue" }> = {
    "Jordan Chen": { initials: "JC", color: "purple" },
    "Alex Kim": { initials: "AK", color: "teal" },
    "Sam Rivera": { initials: "SR", color: "coral" },
    "Morgan Lee": { initials: "ML", color: "blue" },
  };

  const currentAvatar = avatarData[name || "Jordan Chen"] || avatarData["Jordan Chen"];

  const messages = [
    { message: "Hey! How are you?", time: "10:30 AM", variant: "incoming" as const },
    { message: "I'm great! Just working on a new project", time: "10:32 AM", variant: "outgoing" as const },
    { message: "That's awesome! What kind of project?", time: "10:33 AM", variant: "incoming" as const },
    { message: "A messaging app prototype. It's coming along nicely!", time: "10:35 AM", variant: "outgoing" as const },
    { message: "See you tomorrow!", time: "10:36 AM", variant: "incoming" as const },
  ];

  return (
    <div className="min-h-screen bg-[var(--app-bg)] flex flex-col">
      {/* Header */}
      <div className="bg-white px-4 py-4 border-b border-gray-200 flex items-center gap-3">
        <button onClick={() => navigate("/chats")} className="p-1">
          <ArrowLeft size={24} className="text-[var(--text-primary)]" />
        </button>
        <Avatar initials={currentAvatar.initials} color={currentAvatar.color} />
        <h2 className="text-[var(--text-primary)]">{name || "Jordan Chen"}</h2>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6">
        {messages.map((msg, index) => (
          <ChatBubble key={index} {...msg} />
        ))}
      </div>

      {/* Input */}
      <div className="bg-white px-4 py-3 border-t border-gray-200">
        <div className="flex items-center gap-2 max-w-md mx-auto">
          <input
            type="text"
            placeholder="Type a message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="flex-1 px-4 py-3 bg-[var(--app-bg)] rounded-full border-0 text-[var(--text-primary)] placeholder:text-[var(--text-secondary)]"
          />
          <button className="p-3 bg-[var(--app-accent)] text-white rounded-full">
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
