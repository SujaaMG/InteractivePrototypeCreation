import { useNavigate } from "react-router";
import { Avatar } from "../components/Avatar";
import { TabBar } from "../components/TabBar";
import { ArrowLeft, Mail, Phone, MapPin, Calendar } from "lucide-react";

export function Profile() {
  const navigate = useNavigate();

  const infoItems = [
    { icon: Mail, label: "jordan.chen@email.com" },
    { icon: Phone, label: "+1 (555) 123-4567" },
    { icon: MapPin, label: "San Francisco, CA" },
    { icon: Calendar, label: "Joined January 2024" },
  ];

  return (
    <div className="min-h-screen bg-[var(--app-bg)] pb-20">
      {/* Header */}
      <div className="bg-white px-4 py-4 border-b border-gray-200 flex items-center gap-3">
        <button onClick={() => navigate("/feed")} className="p-1">
          <ArrowLeft size={24} className="text-[var(--text-primary)]" />
        </button>
        <h1 className="text-xl text-[var(--text-primary)]">Profile</h1>
      </div>

      {/* Profile Info */}
      <div className="bg-white mt-4 p-6">
        <div className="flex flex-col items-center">
          <Avatar initials="JC" color="purple" size="lg" />
          <h2 className="text-xl text-[var(--text-primary)] mt-4">Jordan Chen</h2>
          <p className="text-[var(--text-secondary)] mt-1">Software Developer</p>
          <p className="text-sm text-[var(--text-secondary)] mt-3 text-center max-w-sm">
            Passionate about building great user experiences and solving complex problems with code.
          </p>
        </div>
      </div>

      {/* Contact Info */}
      <div className="bg-white mt-4">
        {infoItems.map((item, index) => {
          const Icon = item.icon;
          return (
            <div
              key={index}
              className={`flex items-center gap-4 px-6 py-4 ${
                index !== infoItems.length - 1 ? "border-b border-gray-100" : ""
              }`}
            >
              <Icon size={20} className="text-[var(--text-secondary)]" />
              <span className="text-[var(--text-primary)]">{item.label}</span>
            </div>
          );
        })}
      </div>

      {/* Actions */}
      <div className="bg-white mt-4">
        <button className="w-full px-6 py-4 text-left text-[var(--app-accent)] border-b border-gray-100">
          Edit Profile
        </button>
        <button className="w-full px-6 py-4 text-left text-[var(--text-primary)]">
          Settings
        </button>
      </div>

      <TabBar />
    </div>
  );
}
