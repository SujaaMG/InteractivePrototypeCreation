import { useNavigate } from "react-router";
import { ListRow } from "../components/ListRow";
import { TabBar } from "../components/TabBar";

export function Feed() {
  const navigate = useNavigate();

  const feedItems = [
    {
      name: "Jordan Chen",
      preview: "Just shared a new photo",
      initials: "JC",
      color: "purple" as const,
      time: "2m",
    },
    {
      name: "Alex Kim",
      preview: "Updated their status",
      initials: "AK",
      color: "teal" as const,
      time: "15m",
    },
    {
      name: "Sam Rivera",
      preview: "Commented on your post",
      initials: "SR",
      color: "coral" as const,
      time: "1h",
    },
    {
      name: "Morgan Lee",
      preview: "Started following you",
      initials: "ML",
      color: "blue" as const,
      time: "3h",
    },
  ];

  return (
    <div className="min-h-screen bg-[var(--app-bg)] pb-20">
      <div className="bg-white px-4 py-6 border-b border-gray-200">
        <h1 className="text-2xl text-[var(--text-primary)]">Feed</h1>
      </div>

      <div className="mt-4">
        {feedItems.map((item, index) => (
          <div key={index} className="mb-1">
            <ListRow
              {...item}
              onClick={() => {
                if (item.name === "Jordan Chen") {
                  navigate("/profile");
                } else {
                  navigate("/chats");
                }
              }}
            />
          </div>
        ))}
      </div>

      <TabBar />
    </div>
  );
}
