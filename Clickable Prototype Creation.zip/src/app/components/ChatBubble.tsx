interface ChatBubbleProps {
  message: string;
  time: string;
  variant: "incoming" | "outgoing";
}

export function ChatBubble({ message, time, variant }: ChatBubbleProps) {
  if (variant === "outgoing") {
    return (
      <div className="flex justify-end mb-4">
        <div className="flex flex-col items-end max-w-[75%]">
          <div className="bg-[var(--app-accent)] text-white px-4 py-3 rounded-2xl rounded-br-md">
            {message}
          </div>
          <span className="text-xs text-[var(--text-secondary)] mt-1">{time}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start mb-4">
      <div className="flex flex-col items-start max-w-[75%]">
        <div className="bg-white text-[var(--text-primary)] px-4 py-3 rounded-2xl rounded-bl-md">
          {message}
        </div>
        <span className="text-xs text-[var(--text-secondary)] mt-1">{time}</span>
      </div>
    </div>
  );
}
