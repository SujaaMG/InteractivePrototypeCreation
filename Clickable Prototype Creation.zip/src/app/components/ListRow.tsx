import { Avatar } from "./Avatar";

interface ListRowProps {
  name: string;
  preview: string;
  initials: string;
  color: "purple" | "teal" | "coral" | "blue";
  onClick?: () => void;
  time?: string;
  unread?: boolean;
}

export function ListRow({
  name,
  preview,
  initials,
  color,
  onClick,
  time,
  unread,
}: ListRowProps) {
  return (
    <div
      className="flex items-center gap-3 p-4 bg-white cursor-pointer hover:bg-gray-50 active:bg-gray-100"
      onClick={onClick}
    >
      <Avatar initials={initials} color={color} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1">
          <h4 className="text-[var(--text-primary)] truncate">{name}</h4>
          {time && (
            <span className="text-xs text-[var(--text-secondary)] ml-2">{time}</span>
          )}
        </div>
        <p className="text-sm text-[var(--text-secondary)] truncate">{preview}</p>
      </div>
      {unread && (
        <div className="w-2 h-2 bg-[var(--app-accent)] rounded-full shrink-0" />
      )}
    </div>
  );
}
