interface AvatarProps {
  initials: string;
  color?: "purple" | "teal" | "coral" | "blue";
  size?: "sm" | "md" | "lg";
}

export function Avatar({ initials, color = "purple", size = "md" }: AvatarProps) {
  const colorClasses = {
    purple: "bg-[var(--avatar-purple-bg)] text-[var(--avatar-purple-text)]",
    teal: "bg-[var(--avatar-teal-bg)] text-[var(--avatar-teal-text)]",
    coral: "bg-[var(--avatar-coral-bg)] text-[var(--avatar-coral-text)]",
    blue: "bg-[var(--app-accent)] text-white",
  };

  const sizeClasses = {
    sm: "w-10 h-10 text-sm",
    md: "w-12 h-12 text-base",
    lg: "w-16 h-16 text-lg",
  };

  return (
    <div
      className={`${sizeClasses[size]} ${colorClasses[color]} rounded-full flex items-center justify-center shrink-0`}
    >
      {initials}
    </div>
  );
}
