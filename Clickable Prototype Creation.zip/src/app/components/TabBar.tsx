import { Home, Mail, User } from "lucide-react";
import { useNavigate, useLocation } from "react-router";

export function TabBar() {
  const navigate = useNavigate();
  const location = useLocation();

  const tabs = [
    { icon: Home, label: "Feed", path: "/feed" },
    { icon: Mail, label: "Chats", path: "/chats" },
    { icon: User, label: "Profile", path: "/profile" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 safe-area-bottom">
      <div className="flex justify-around items-center max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = location.pathname === tab.path;
          return (
            <button
              key={tab.path}
              onClick={() => navigate(tab.path)}
              className="flex flex-col items-center gap-1 py-2 px-6"
            >
              <Icon
                size={24}
                className={isActive ? "text-[var(--app-accent)]" : "text-[var(--text-secondary)]"}
              />
              <span
                className={`text-xs ${
                  isActive ? "text-[var(--app-accent)]" : "text-[var(--text-secondary)]"
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
