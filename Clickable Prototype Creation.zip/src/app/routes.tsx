import { createBrowserRouter } from "react-router";
import { Login } from "./screens/Login";
import { Feed } from "./screens/Feed";
import { Chats } from "./screens/Chats";
import { Thread } from "./screens/Thread";
import { NewMessage } from "./screens/NewMessage";
import { Profile } from "./screens/Profile";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/feed",
    Component: Feed,
  },
  {
    path: "/chats",
    Component: Chats,
  },
  {
    path: "/thread/:name",
    Component: Thread,
  },
  {
    path: "/new-message",
    Component: NewMessage,
  },
  {
    path: "/profile",
    Component: Profile,
  },
]);
