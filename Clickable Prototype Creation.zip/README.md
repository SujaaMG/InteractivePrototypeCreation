
  # Clickable Prototype Creation

  This is a code bundle for Clickable Prototype Creation. The original project is available at https://www.figma.com/design/yspacdV5loGmvC349nt7zv/Clickable-Prototype-Creation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  